package ru.job4j.myclass;

import java.util.Scanner;

public class Myexcetion {
    public static void main(String[] args) {
        int x = new Scanner(System.in).nextInt();
        int y = new Scanner(System.in).nextInt();
        try {
            double res = x / y;
            System.out.println(res);
        } catch (Exception myErr) {
            System.out.println("Делить на 0 нельзя");
        }
        System.out.println("Завершение программы");
    }
}
