package ru.job4j.myclass;

import java.util.Locale;
import java.util.Scanner;

public class Dstring {
    public static void main(String[] args) {
//        String st1 = "Study";
//        String st2 = "Study ";
//        String st3 = st1.concat(st2);
//        System.out.println(st2.trim());
//        System.out.println(st2.toLowerCase());
//        if (st1.equalsIgnoreCase(st2)) {
//            System.out.println("Равны");
//        } else {
//            System.out.println("Не равны");
//        }
//   System.out.println(st3.charAt(3));
//        System.out.println(st3);
//    }
//        StringBuilder str1 = new StringBuilder("RKGT");
//        StringBuilder str2 = new StringBuilder("- best");
//        StringBuilder str3 = new StringBuilder("college");
//        System.out.println(str1.charAt(3));
//        str1.setCharAt(2, 'J');
//        System.out.println(str1);
//        str2.append("EYS");
//        System.out.println(str2);
//        str1.insert(2, 'g');
//        System.out.println(str1);
//        str3.delete(2, 4);
//        System.out.println(str3);
//        str2.replace(5, 7, "OK");
//        System.out.println(str2);
//        str1.reverse();
//        System.out.println(str1);
        StringBuffer str1 = new StringBuffer("Программа");
        str1.delete(0, 3);
        System.out.println(str1);
        str1.delete(5, 6);
        System.out.println(str1); // можно делать str1.delete(0, 3).delete(5, 6);
        StringBuffer str2 = new StringBuffer("Программа");
        str2.delete(0, 7).append("ма");
        System.out.println(str2);
        System.out.println("Введите имя ");
        String name1 = new Scanner(System.in).nextLine();
        System.out.println("Введите имя ");
        String name2 = new Scanner(System.in).nextLine();
        if (name1.equals(name2)) {
            System.out.println("РАВНЫ");
        } else {
            System.out.println("НЕ РАВНЫ");
        }
    }
}

