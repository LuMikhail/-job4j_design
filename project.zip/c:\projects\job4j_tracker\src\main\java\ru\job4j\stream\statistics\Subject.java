package ru.job4j.stream.statistics;

/**
 *  Класс Subject описывает школьный предмет и аттестационный балл ученика.
 */
public record Subject(String name, int score) {
}
