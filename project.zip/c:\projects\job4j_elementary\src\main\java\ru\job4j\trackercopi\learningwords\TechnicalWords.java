package ru.job4j.trackercopi.learningwords;

import java.util.Arrays;

public class TechnicalWords {
    public static void main(String[] args) {
        String[] technicalWords = {"переменные, параметры;", "предыдущий, прежний, прошлый, ранний(early former last);",
                "раздел подраздел;", "поле(box), область сфера;", "введенный, внесенный, entered brought, внедренный entered brought embedded;",
                "правила regulation, условия;", "относится;", "распространенный;", "определяет;", "типы - k;", "по умолчанию;",
                "режим режим работы regime operating ___, способ метод method вид форма type form;", "расширять расширить расширяться,преодлевать продлить продлять prolong;",
                "реализовать;", "обеспечивать, предусматривать, предоставлять;",

                "доступный, имеющийся;", "экземпляр,пример, инстанция, образец, (ссылаться, приводить в качестве примера, служить примером);",
                "заказ, порядок, орден (заказывать, приказывать, упорядочивать);", "повторять, перебирать;", "до тех пор пока, до того как;",
                "который, какой;", "диапазон, ряд, круг (выстраивать в ряд, простираться, тянуться);", "несколько (некоторые, каждый, отдельный);",
                "потерпеть неудачу;", "обязанность, ответственность;", "способный, в состоянии, умеющий;", "cравнивать, сравниться, сопоставлять;"

        };
        System.out.println("Здравствуйте,  это программа поможет вам выучить технические слова JAVA");
        System.out.println("            НАЧНЕМ:");
        Irregularverbs verbs = new Irregularverbs();
        long start = System.currentTimeMillis();
        String[] repeatWords = verbs.learningWords(technicalWords); // так как метод возвращает String[] мы сначала воспроизводим words
        // а затем записываем новый массив из слов в которых мы ошиблись.
        if (repeatWords.length > 0) { // если есть ошибки
            for (String w : repeatWords) {
                System.out.println(w);
            }
            System.out.println("\n повторим один раз \n");
            String[] againRepeat = verbs.learningWords(repeatWords); // то записываем в новый масcив
            if (againRepeat.length > 0) {
                System.out.println(Arrays.toString(againRepeat));
                verbs.learningWords(againRepeat); // опять повторяем слова в которых допустили ошибки
            }
        }
        float finish = (float) (System.currentTimeMillis() - start) / 60000;
        System.out.println("Время выполнение упражнения составляет " + finish + " минут");
    }
}
