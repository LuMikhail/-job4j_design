package ru.job4j.inheritance;

public class Cat {
    public boolean canPurr() {
        return true;
    }
}
