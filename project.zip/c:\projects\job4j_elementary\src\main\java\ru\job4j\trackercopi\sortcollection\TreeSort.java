package ru.job4j.trackercopi.sortcollection;

import java.util.Collections;
import java.util.TreeSet;

public class TreeSort {
    public static void main(String[] args) {
        TreeSet<Integer> numbers = new TreeSet<>(Collections.reverseOrder());
        Collections.addAll(numbers, 5, 1, 3);
        System.out.println(numbers);
    }
}
