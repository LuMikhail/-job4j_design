package ru.job4j.poly;

public class GuineaPig extends Pet {
    public void runInWheel() {
        System.out.println(nameClass + "  любит побегать в колесе.");
    }
}
