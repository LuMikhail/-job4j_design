package ru.job4j.trackercopi.oop;

public class BallStory {

    public static void main(String[] args) {
        Ball ball = new Ball();
        Hare hare = new Hare();
        Wolf wolf = new Wolf();
        Fox fox = new Fox();
        hare.eat(ball);
        wolf.eat(ball);
        fox.eat(ball);
    }
}
