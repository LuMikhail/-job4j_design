package ru.job4j.trackercopi.algorithm;

import java.util.Arrays;

public class SortInsert {
    public static void main(String[] args) {
        int[] arr = {5, 7, 18, 6, 19, 25, 14, 3, 8, 29};
        System.out.println(Arrays.toString(arr));
        for (int step = 0; step < arr.length; step++) {
            int index = min(arr, step);
            int temp = arr[step];
            arr[step] = arr[index];
            arr[index] = temp;
        }
        System.out.println(Arrays.toString(arr));
    }

    public static int min(int[] args, int index) {
        for (int i = index + 1; i < args.length; i++) {
            if (args[i] < args[index]) {
                int temp = args[i];
                args[i] = args[index];
                args[index] = temp;
            }
        }
        return index;
    }
}
