package ru.job4j.trackercopi.shablonstrateg;

public class AxeBehavior implements WeaponBehavior {
    @Override
    public void useWeapon() {
        System.out.println("I hit Axe");
    }
}
