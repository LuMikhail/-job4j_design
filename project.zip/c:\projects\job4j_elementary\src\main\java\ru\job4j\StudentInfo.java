package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Mikhail");
        System.out.println("08.04.1984");
    }
}