package ru.job4j.trackercopi.lamda;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.*;

public class FunctionInterfaceUsage {
    @SuppressWarnings("checkstyle:NoWhitespaceBefore")
    public static void main(String[] args) {
        //Supplier (поставщик) используется для создания какого-либо объекта и при этом ему не требуется входной параметр.
        //В самом начале мы объявляем интерфейс Supplier с обобщенным типом String и записываем его в переменную sup.
        // Основное применение этого интерфейса – создание новых объектов.
        // T get();

        Supplier<String> sup = () -> "New String For Interface";
        System.out.println(sup.get());
        List<String> list = java.util.List.of("one", "two", "three", "one", "two", "three");
        Supplier<Set<String>> stringSupplier = () -> new HashSet<>(list);
        Set<String> strings = stringSupplier.get();
        for (String s : strings) {
            System.out.println(s);
        }
        //Consumer (потребитель) используется в том случае, если нам нужно применить какое-то действие или операцию к
        // параметру (для BiConsumer два параметра) и при этом у метода нет возвращаемого значения.
        // Объявляются эти интерфейсы следующим образом:
        //Два интерфейса отличаются только одним – количеством параметров, которые принимает метод в этом интерфейсе.
        // Это относится ко всем интерфейсам – если видите приставку Bi – значит отличие лишь в количестве параметров.
        // Вернемся к ранее написанному примеру и перепишем вывод в консоль на применение интерфейса Consumer:

        BiConsumer<String, String> consumer = (s, s1) -> System.out.println(s + s1);
        consumer.accept(sup.get(), " and Second String");

        //При этом Важно понимать – параметры в Biconsumer могут быть разных типов – перепишем пример с коллекцией
        //       void accept(T t, U u);
        // из 1 пункта следующим образом:
        List<String> list2 = List.of("one", "two", "three", "one", "two", "three");
        Supplier<Set<String>> sup2 = () -> new HashSet<>(list2);
        BiConsumer<Integer, String> consumer2 = (s, s1) -> System.out.println(s + s1);
        Set<String> strings2 = sup2.get();
        int i = 1;
        for (String s : strings2) {
            consumer2.accept(i++, " is " + s);
        }
        //Predicate (утверждение) наиболее часто применяется в фильтрах и сравнении и объявляются они следующим образом:
        //       boolean test(T t, U u);
        //Т.е. в метод test() передается один или два параметра, в зависимости от функционального интерфейса и возвращает
        // логическое значение true или false. Посмотрим, как это работает на простом примере – проверим не является
        // ли передаваемая строка пустой:
        Predicate<String> pred = s -> s.isEmpty();
        System.out.println("Строка пустая: " + pred.test(""));
        System.out.println("Строка пустая: " + pred.test("test"));
        //Как и в предыдущем пункте при работе с Bi-формой нам требуется передавать 2 параметра:
        BiPredicate<String, Integer> cond = (s, in) -> s.contains(in.toString());
        System.out.println("Строка содержит подстроку: " + cond.test("Name123", 123));
        System.out.println("Строка содержит подстроку: " + cond.test("Name", 123));
        // Т.е. в данном случае мы проверяем что в нашей строке содержится передаваемое число, которое мы предварительно
        // преобразуем в строку.
        //
        //Function используется для преобразования входного параметра или двух параметров
        // (для Bi-формы этого функционального интерфейса) в какое-либо значение, тип возвращаемого значения может
        // не совпадать с типом входных параметров. Объявляются интерфейсы следующим образом:
        //     R apply(T t);
        //     R apply(T t, U u);
        Function<String, Character> func = s -> s.charAt(2);
        System.out.println("Третий символ в строке: " + func.apply("first"));
        System.out.println("Третий символ в строке: " + func.apply("second"));
        // Надеемся вы обратили внимание, несмотря на то, что в лямбда-выражение передается один параметр,
        // в обобщенных типах мы должны указать 2 параметра – вторым параметром мы указываем тип возвращаемого значения
        // (в нашем случае это Character). Давайте попробуем воспользоваться возможностями Bi-формы функционального интерфейса,
        // при этом типы принимаемых значений не будут совпадать:
        BiFunction<String, Integer, String> biFunc = (s, in) -> s.concat(" ").concat(in.toString());
        System.out.println("Результат работы бифункции: " + biFunc.apply("Name", 123));
        System.out.println("Результат работы бифункции: " + biFunc.apply("String number", 12345));
        // Очень важно понимать, что все три типа в обобщениях в BiFunction могут быть разными: принимает на вход
        // 2 разных типа и возвращает третий тип.
    }
}
