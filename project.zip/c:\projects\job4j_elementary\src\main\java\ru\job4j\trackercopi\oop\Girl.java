package ru.job4j.trackercopi.oop;

public class Girl {

    public void help(Pioneer pioneer) {

    }
}
