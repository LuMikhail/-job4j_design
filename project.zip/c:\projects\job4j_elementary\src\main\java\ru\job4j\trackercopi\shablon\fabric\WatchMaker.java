package ru.job4j.trackercopi.shablon.fabric;

public interface WatchMaker {
    Watch createWatch();
}
 // это фабричный интерфейс