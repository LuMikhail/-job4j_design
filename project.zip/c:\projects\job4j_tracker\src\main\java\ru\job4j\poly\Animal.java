package ru.job4j.poly;

public class Animal {
   String nameClass = getClass().getSimpleName();

   public void sound() {
       System.out.println(nameClass + "- издает какойто звук");
   }
}
