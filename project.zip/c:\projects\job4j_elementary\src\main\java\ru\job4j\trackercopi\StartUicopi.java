package ru.job4j.trackercopi;

import java.util.ArrayList;
import java.util.Arrays;

public class StartUicopi {
    /*private final Output out;

    public StartUicopi(Output out) {
        this.out = out;
    }

    //   public void init(Input input, Tracker tracker, UserAction[] actions) {
    public void init(Input input, Tracker tracker, ArrayList<UserAction> actions) {
        boolean run = true;
        while (run) {
            this.showMenu(actions);
            int select = input.askInt("Select: ");
            //  if (select < 0 || select >= actions.length) {
            if (select < 0 || select >= actions.size()) {
                out.println("Wrong input, you can select: 0 .. " + (actions.size() - 1));
             //   out.println("Wrong input, you can select: 0 .. " + (actions.size() - 1));

                continue;
            }
            //  UserAction action = actions[select];
            UserAction action = actions.get(select);
            run = action.execute(input, tracker);
        }
    }

    // private void showMenu(UserAction[] actions) {
    private void showMenu(ArrayList<UserAction> actions) {
        out.println("Menu:");
        //for (int i = 0; i < actions.length; i++) {
        for (int i = 0; i < actions.size(); i++) {
            //  out.println(i + ". " + actions[i].name());
            out.println(i + ". " + actions.get(i).name());

        }
    }

    public static void main(String[] args) {
        Output output = new ConsoleOutput();
        Input input = new ValidateInput(output, new ConsoleInput());
        Tracker tracker = new Tracker();
        ArrayList<UserAction> actions = new ArrayList<>(Arrays.asList(
                new CreateAction(output), new ShowAction(output), new EditAction(output),
                new DeleteAction(output), new FindIdAction(output), new FindNameAction(output),
                new ExitAction()
            )
        );
        new StartUicopi(output).init(input, tracker, actions);
    }*/
}
