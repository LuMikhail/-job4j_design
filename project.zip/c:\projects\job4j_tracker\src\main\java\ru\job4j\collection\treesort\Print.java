package ru.job4j.collection.treesort;

public class Print {
    public static void main(String[] args) {
        System.out.println("Привет");
    }
}
