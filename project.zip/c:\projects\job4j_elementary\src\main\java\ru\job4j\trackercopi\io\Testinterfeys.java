package ru.job4j.trackercopi.io;

public class Testinterfeys {
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.sleep();
        animal.walk();

        Sleepable sleepableObg = new Animal();
        sleepableObg.sleep();
    }
}
