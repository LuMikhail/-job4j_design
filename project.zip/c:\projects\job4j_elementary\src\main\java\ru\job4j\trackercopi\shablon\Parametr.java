package ru.job4j.trackercopi.shablon;

public class Parametr {
    public static void main(String[] args) {
        Parametr sum2 = new Parametr();
        System.out.println("sum2 = " + sum2); // печатается ссылка так  sum2 не имеет метда печати
        sum2.sum("TOm");
        sum2.sum();
        System.out.println();
        sum2.sum("tomas", 10, 20, 30, 4);
        int result = sum2.sum("tomas", 10, 20, 30, 4);
        System.out.println("result = " + result + " " + sum2.sum("Jon", 1, 2, 3));
        System.out.println();
        int result2 = sum2.sum();
        System.out.println("result 2 = " + result2);
    }

    private int sum(String messeg, int... nums) {
        System.out.println("messeg = " + messeg);
        int rsl = 0;
        for (int x : nums) {
            rsl += x;
            System.out.println("rsl = " + messeg + " " + x + " " + rsl);
        }
        return rsl;
    }

    private int sum() {
        String messeg = "MAMA";
        System.out.println("messeg = " + messeg);
        int rsl = 0;
        int[] nums = {
            50, 40, 80
        };
        for (int num : nums) {
            rsl += num;
            System.out.println("rsl = " + messeg + " " + num + " " + rsl);
        }
        return rsl;
    }
}


