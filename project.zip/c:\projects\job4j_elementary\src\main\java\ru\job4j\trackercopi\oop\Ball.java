package ru.job4j.trackercopi.oop;

public class Ball {

    public void truRun(boolean condition) {
        if (condition) {
            System.out.println("Колобок будет съеден");
        } else {
            System.out.println("Колобок сбежал");
        }
    }
}
