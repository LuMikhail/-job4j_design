package ru.job4j.recursion;

public class Practice {
    public static void main(String[] args) {
        System.out.println(sum(10));
        System.out.println(foctorial(10));
        String s = "apple"; // elppa
        System.out.println(reverse(s));
    }

    public static int sum(int n) {
       if (n == 1) {
           return 1; // base step
       }
        return n + sum(n - 1); // recursive step 10 + sum(9) = 9 + sum(8) = 8 + sum(7) ...
        // 10 + 9 + 8 + 7 + 6 + 5 + 4 + 3 + 3
    }

    public static int foctorial(int i) {
        if (i == 1) {
            return 1;
        }
        return  i * foctorial(i - 1);
    }

    public static String reverse(String s) {
        if (s.length() == 1) {
            return s;
        }
        return s.charAt(s.length() - 1) + reverse(s.substring(0, s.length() - 1));
    }

}
