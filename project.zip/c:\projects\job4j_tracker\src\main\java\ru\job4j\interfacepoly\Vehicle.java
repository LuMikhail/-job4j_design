package ru.job4j.interfacepoly;

public interface Vehicle {

    void move();

    void speed();
}
