package ru.job4j.trackercopi;

import java.util.ArrayList;
import java.util.Arrays;

public class TrackerCopi {

  /*  //   private final Item[] items = new Item[100];
    private final ArrayList<Item> items = new ArrayList<>();
    private int ids = 1;
    private int size = 0;

    public Item add(Item item) {
        item.setId(ids++);
        //items[size++] = item;
        items.add(item);
        return item;
    }

    private int indexOf(int id) {
        int rsl = -1;
        for (int index = 0; index < items.size(); index++) {
            //  if (items[index].getId() == id) {
            if (items.get(index).getId() == id) {
                rsl = index;
                break;
            }
        }
        return rsl;
    }

    public boolean replace(int id, Item item) {
        int index = indexOf(id);
        boolean rsl = index != -1;
        if (rsl) {
            //  items[index] = item;
            items.set(index, item);
            item.setId(id);
        }
        return rsl;
    }

    public boolean delete(int id) {
        int index = indexOf(id);
        boolean rsl = index != -1;
        if (rsl) {
         *//*   System.arraycopy(items, index + 1, items, index, size - index - 1);
            //  items[size - 1] = null;
            size--;*//*
            items.remove(index);
        }
        return rsl;
    }

    public Item findById(int id) {
        int index = indexOf(id);
        // return index != -1 ? items[index] : null;
        return index != -1 ? items.get(index) : null;
    }

    public Item[] findAll() {
  //  public ArrayList<Item> findAll() {
        //  return Arrays.copyOf(items, size);
        return items.toArray(new Item[0]);
      //  return items;
    }

    public Item[] findByName(String key) {
        int count = 0;
        Item[] rsl = new Item[items.size()];
        for (int index = 0; index < items.size(); index++) {
            //    if (items[index].getName().equals(key)) {
            if (items.get(index).getName().equals(key)) {
                //  rsl[count] = items[index];
                rsl[count] = items.get(index);
                count++;
            }
        }
        return Arrays.copyOf(rsl, count);
    }*/
}
