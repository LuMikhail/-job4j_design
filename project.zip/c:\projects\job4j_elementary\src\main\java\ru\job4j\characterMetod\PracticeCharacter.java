package ru.job4j.characterMetod;

public class PracticeCharacter {
    public static void main(String[] args) {
        char c = 'a';
        char d = 'B';
        System.out.println(Character.isDigit(c));
        System.out.println(Character.isLetter(c));
        System.out.println(Character.isLetterOrDigit(c));
        System.out.println(Character.isLowerCase(c));
        System.out.println(Character.isUpperCase(c));
        System.out.println(Character.toLowerCase(d));
        System.out.println(Character.toUpperCase(c));
    }
}
