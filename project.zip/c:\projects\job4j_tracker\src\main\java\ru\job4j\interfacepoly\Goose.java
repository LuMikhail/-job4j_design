package ru.job4j.interfacepoly;

public class Goose implements Animal {
    @Override
    public void sound() {
        System.out.println(getClass().getSimpleName() + " приносит перо для подушек.");
    }
}
