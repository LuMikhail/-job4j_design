package ru.job4j.myclass;

import java.util.Arrays;

public class Leson11 {
    public static void main(String[] args) {
        int[] zp = new int[30];
        int summe = 0;
        int min = 10000;
        int max = 0;
        for (int i = 0; i < zp.length; i++) {
            zp[i] = (int) (Math.random() * 500 + 200);
            summe += zp[i];
            if (min > zp[i]) {
                min = zp[i];
            }
            if (max < zp[i]) {
                max = zp[i];
            }
            System.out.println(Arrays.toString(zp));
            System.out.println("Итого общая зарплата = " + summe);
            System.out.println(min);
            System.out.println(max);
        }
    }
}