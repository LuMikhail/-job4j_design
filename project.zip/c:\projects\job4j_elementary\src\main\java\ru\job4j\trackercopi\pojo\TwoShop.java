package ru.job4j.trackercopi.pojo;

import java.util.Arrays;

public class TwoShop {
    public static void main(String[] args) {
        Product[] products = new Product[4];
        products[0] = new Product("Milk", 10);
        products[1] = new Product("Bread", 4);
        products[2] = new Product("Egg", 19);
        products[3] = new Product("Appel", 35);

        for (int i = 0; i < products.length; i++) {
            Product product = products[i];
            System.out.println(product.getName());
        }
 /*       products[1] = products[2];
        products[2] = null;
        for (int i = 0; i < products.length; i++) {
            Product product = products[i];
            if (product != null) {
                System.out.println(product.getName());
            } else {
                System.out.println("null");
            }*/
        System.out.println();
        products = ShopDrop.delete(products, 2);
        for (int j = 0; j < products.length - 1; j++) {
            Product endDelet = products[j];
            System.out.println(endDelet.getName() + " " + endDelet.getCount());
        }
        System.out.println();
        for (int m = 0; m < products.length - 1; m++) {
            Product product3 = products[m];
            System.out.println(product3.getName() + product3.getCount());
        }
        System.out.println(Arrays.toString(products));
    }
}
