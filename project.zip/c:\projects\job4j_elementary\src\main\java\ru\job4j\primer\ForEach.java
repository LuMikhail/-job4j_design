package ru.job4j.primer;

public class ForEach {
    public static void main(String[] args) {
        int[] arr = new int[30];
        arr[0] = 1;
        arr[1] = 5;
        arr[2] = 17;
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
        }
        for (int e : arr
             ) {
            System.out.print(e);
        }
        System.out.println();
        int[][] matrix;
        matrix = new int[][]{
                {1, 2, 3},
                {4, 5, 6}
        };
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
