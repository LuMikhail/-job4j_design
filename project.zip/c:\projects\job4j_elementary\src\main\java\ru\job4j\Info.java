package ru.job4j;

public class Info {
    public static void main(String[] args) {
        System.out.println("21.09.2021");

    }
}
