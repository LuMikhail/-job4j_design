package ru.job4j.condition;

public class Liken {
    public static void main(String[] args) {
        int first = 10;
        int second = 9;
        boolean result = first > second; /* first больше second? */
        boolean result2 = first < second; /* first меньше second? */
        boolean result3 = first == second; /* first равна second? */
        System.out.println(result);
        System.out.println(result2);
        System.out.println(result3);
    }
}
