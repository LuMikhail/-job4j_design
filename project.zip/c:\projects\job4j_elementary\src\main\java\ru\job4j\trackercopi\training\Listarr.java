package ru.job4j.trackercopi.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Listarr {
    public static void main(String[] args) {
        List<Integer> name = new ArrayList<>();
        name.add(2);
        name.add(3);
        name.add(7);
        System.out.println(name);
        List<Integer> name2 = new ArrayList<>();
        name2.add(9);
        name2.add(1);
        name2.add(4);
        name2.addAll(name);
        System.out.println(name2);
        name2.removeAll(name);
        System.out.println(name2);
        System.out.println(name);
        name.removeIf(f -> f > 2);
        System.out.println(name);
        name2.sort((integer, anotherInteger) -> integer.compareTo(anotherInteger));
        System.out.println(name2);
        name2.sort(Comparator.reverseOrder());
        System.out.println(name2);
        name2.sort(null);
        System.out.println(name2);
        System.out.println(Collections.max(name2));
        int min = Collections.min(name);
        System.out.println(min);
        name2.set(2, 13);
        System.out.println(name2);
        System.out.println(name2.get(0));
        System.out.println(name2.isEmpty());
        System.out.println(name2.contains(4));
        System.out.println(name2.containsAll(name));
    }
}
