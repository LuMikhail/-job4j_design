package ru.job4j.stringmetod;

import java.util.Locale;

public class PracticeString {
    public static void main(String[] args) {
        String s = " Welcome to Java ";
        String ss = new String("Welcome");
        System.out.println(s.length() + " " + s);
        System.out.println(s.charAt(14)); // указываем индекс и выводит символ
        System.out.println(s.concat(ss)); // соединяет но редко используетсе так как есть "+"
        System.out.println(s + ss);
        System.out.println(s.toLowerCase());
        System.out.println(s.toUpperCase());
        System.out.println(s.trim()); // удаляет в начале и в конце пробелы
        System.out.println();
        String a = "Welcome to Java";
        String b = "Welcome to Java";
        if (a.equals(b)) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
        String e = "Welcome to Java";
        String f = "welcome to Java";
        if (e.equalsIgnoreCase(f)) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
        System.out.println(e.compareTo(f)); // очень важный метод проверят строки три варианта отрицательный положительный и ноль
        System.out.println();

        String g = "welcome to Java";
        System.out.println(g.indexOf('J')); // можно искать как символ так и слова или группу символов
        System.out.println(g.indexOf("come", 2)); //indexOf("come", 2)); два указывает с какого места индекса искать
        System.out.println(g.indexOf("comert")); // нет такого индекса поэтому - 1

        System.out.println();

        String h = "Welcome to Java";
        System.out.println(h.substring(3, 7)); // указываем с какого начинать индекса и по какой по 6 включительно
        System.out.println(h.substring(3));
    }
}
