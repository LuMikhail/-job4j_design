package ru.job4j.trackercopi.learningwords;

import java.util.Random;
import java.util.Scanner;
import java.util.Arrays;

public class Irregularverbs {

    public static void main(String[] args) throws InterruptedException {
        String[] irrregulVer = {/*"выигрывать", "устанавливать", "читать", "мириться (с обстоятельствами) соблюдат",
                "появляться", "носить (имя; вещи: чемодан и т. д.); переносить; передавать (новости); вести себя (bear oneself)", "быть", "бить",
                "начинать", "гнуть; наклоняться", "просить, умолять", "держать пари", "вязать, связывать", "разводить; воспитывать",
                "приносить; приводить", "строить", "гореть", "лопнуть, взорваться; разразиться; прорывать (о плотине)", "покупать", "бросать",
                "ловить, поймать", "выбирать", "приходить, приезжать", "стоить", "ползать", "резать", "заниматься, иметь дело", "копать", "делать",
                "рисовать", "мечтать; сниться", "пить", "водить машину", "жить; поселить", "есть", "падать", "кормить", "чувствовать; думать",
                "бороться", "находить", "подходить по размеру", "бежать, скрыться", "бросить; броситься", "летать", "запрещать",
                "ударять не Beat", "класть", "прогнозировать", "забывать", "прощать", "заморозить; замёрзнуть", "получать", "давать", "идти, ехать",
                "расти; выращивать", "висеть; вешать", "иметь", "слышать", "прятать; прятаться",
                "держать; проводить (мероприятие); поддерживать (беседу)", "причинять боль", "хранить", "вязать", "знать",
                "класть; возглавить", "вести", "значить; предназначать; иметь ввиду", "наклоняться; прислоняться", "вскочить, прыгнуть",
                "учить, изучать", "оставлять", "давать взаймы", "пускать; позволять", "лежать", "освещать", "терять", "делать, создавать",
                "встречать", "ошибаться", "косить, стричь", "платить", "доказывать", "бросать (работу, университет и т д) бросать что-либо делать (курить и т. д.)",
                "ездить", "подняться, вырасти", "бежать; управлять", "пилить", "говорить долго", "видеть", "искать",
                "продавать; продаваться", "посылать", "шить", "встряхивать", "сиять, светить", "стрелять; снимать (фильм)", "показывать", "уменьшать", "закрывать", "петь", "тонуть; топить",
                "сидеть; садиться", "спать", "скользить", "закинуть", "пахнуть; нюхать", "сеять", "быстро проноситься", "писать или произносить по буквам; влечь за собой", "проводить (время); тратить", "пролить",
                "портить", "распространять", "говорить кратко", "стоять; ставить", "красть", "колоть; прикалывать, прикреплять; застревать",
                "жалить", "ударить; врезаться", "стремиться", "клясться; ругаться", "подметать", "разбухать", "плавать", "качать", "брать",
                "учить, обучать", "рвать", "говорить, рассказывать", "думать", "бросать t", "вонзить; толкнуть",*/

                "вонзить; толкнуть", "клясться; ругаться", "висеть; вешать", "закинуть",
                "ступать, наступать", "будить, просыпаться", "носить (одежду)", "плакать", "мочить", "извиваться", "отжать; свернуть", "писать"
        };
        System.out.println("Здравствуйте,  это программа поможет вам выучить не правильные глаголы");
        System.out.println("            НАЧНЕМ:");
        Irregularverbs verbs = new Irregularverbs();
        long start = System.currentTimeMillis();
        String[] repeatVerbs = verbs.learningWords(irrregulVer); // так как метод возвращает String[] мы сначала воспроизводим words
        // а затем записываем новый масиив из слов в которых мы ошиблись.
        if (repeatVerbs.length > 0) { // если есть ошибки
            System.out.println(Arrays.toString(repeatVerbs));
            System.out.println(Arrays.toString(repeatVerbs));
            System.out.println("повторим один раз \n");
            String[] againRepeat = verbs.learningWords(repeatVerbs); // то записываем в новый массив
            if (againRepeat.length > 0) {
                System.out.println(Arrays.toString(againRepeat));
                verbs.learningWords(againRepeat); // опять повторяем слова в которых допустили ошибки
            }
        }
        double finish = (double) (System.currentTimeMillis() - start) / 60000;
        System.out.println("Время выполнение упражнения составляет " + finish + " минут");
    }

    public String[] learningWords(String[] words) {
        System.out.print("слов в этом блоке: ");
        System.out.print(words.length); // печатаем количество глаголов которое равно конец длинны массива
        System.out.println();
        int rsl = 0;
        int attempts = 0; // счетает количество ошибок
        String[] mistakeVerbs = new String[50];
        while (rsl < words.length) {
            String randStr = getRandom(words); // генерируем случайный глагол через индекс массива с глаголами
            words = removeElement(words, randStr); // уменьшаем количество слов на пройденное слово
            System.out.print("Введите слово: ");
            System.out.println(randStr);
            if (randStr.equals("выигрывать")) {
                if (scanner().equals("win won won")) {
                    System.out.println("Все верно");
                } else {
                    System.out.println("Вы допустили ошибку, верно:\n \"win won won\"");
                    scanner();
                    attempts++;
                    addMistake(mistakeVerbs, randStr);
                }
            } else if ((randStr.equals("устанавливать")) && (!scanner().equals("set set set"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"set set set\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("читать")) && (!scanner().equals("read read read"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"read read read\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("мириться (с обстоятельствами) соблюдат")) && (!scanner().equals("abide abode abode"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"abide abode abode\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("будить; просыпаться")) && (!scanner().equals("awake awoke awoken"))) {
                System.out.println("Вы допустили ошибку, верно \"awake awoke awoken\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("появляться")) && (!scanner().equals("arise arose arisen"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"arise arose arisen\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("носить (имя; вещи: чемодан и т. д.); переносить; передавать (новости); вести себя (bear oneself)"))
                    && (!scanner().equals("bear bore borne"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"bear bore borne\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("быть")) && (!scanner().equals("be was were been"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"be was were been\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("бить")) && (!scanner().equals("beat beat beaten"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"beat beat beaten (US also beat)\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("начинать")) && (!scanner().equals("begin began begun"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"begin [bɪ'gɪn]\n began [bɪ'gæn]\n begun [bɪ'gʌn]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("гнуть; наклоняться")) && (!scanner().equals("bend bent bent"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"bend bent bent\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("просить, умолять")) && (!scanner().equals("beseech besought besought"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"beseech [bɪ'si:ʧ] besought [bɪ'sɔ:t] besought [bɪ'sɔ:t]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("держать пари")) && (!scanner().equals("bet bet bet"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"bet bet bet\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("вязать, связывать")) && (!scanner().equals("bind bound bound"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"bind bound bound\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("дуть")) && (!scanner().equals("blow blew blown"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"blow [bləʊ] blew [blu:] blown [bləʊn]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("ломать")) && (!scanner().equals("break broke broken"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"break [breɪk] broke [brəʊk] broken ['brəʊkən]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("разводить; воспитывать")) && (!scanner().equals("breed bred bred"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"breed [bri:d] bred [bred] bred [bred]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("приносить; приводить")) && (!scanner().equals("bring brought brought"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"bring [brɪŋ] brought [brɔ:t] brought [brɔ:t]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("строить")) && (!scanner().equals("build built built"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"build [bɪld] built [bɪlt] built [bɪlt]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("гореть")) && (!scanner().equals("burn burnt burnt"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"burn [bз:n] гореть burnt [bз:nt] burnt [bз:nt]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("лопнуть, взорваться; разразиться; прорывать (о плотине)")) && (!scanner().equals("burst burst burst"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"burst [bз:st] burst [bз:st] burst [bз:st]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("покупать")) && (!scanner().equals("buy bought bought"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"buy [baɪ] bought [bɔ:t] bought [bɔ:t]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("бросать")) && (!scanner().equals("cast cast cast"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"cast [kɑ:st] cast [kɑ:st] cast [kɑ:st]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("ловить, поймать")) && (!scanner().equals("catch caught caught"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"catch [kæʧ] caught [kɔ:t] caught [kɔ:t]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("выбирать")) && (!scanner().equals("choose chose chosen"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"choose [ʧu:z] chose [ʧəʊz] chosen ['ʧəʊzən]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("приходить, приезжать")) && (!scanner().equals("come came come"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"come [kʌm] came [keɪm] come [kʌm]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("стоить")) && (!scanner().equals("cost cost cost"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"cost [kɒst] cost [kɒst] cost [kɒst]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("ползать")) && (!scanner().equals("creep crept crept"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"creep [kri:p] crept [krept] crept [krept]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("резать")) && (!scanner().equals("cut cut cut"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"cut [kʌt] cut [kʌt] cut [kʌt]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("заниматься, иметь дело")) && (!scanner().equals("deal dealt dealt"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"deal [di:l] dealt [delt] dealt [delt]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("копать")) && (!scanner().equals("dig dug dug"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"dig [dɪg] dug [dʌg] dug [dʌg]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("делать")) && (!scanner().equals("do did done"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"do [du:] did [dɪd] done [dʌn]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("рисовать")) && (!scanner().equals("draw drew drawn"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"draw [drɔ:] drew [dru:] drawn [drɔ:n]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("мечтать; сниться")) && (!scanner().equals("dream dreamt dreamt"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"dream [dri:m] dreamt [dremt] (dreamed) dreamt [dremt] (dreamed)\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("пить")) && (!scanner().equals("drink drank drunk"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"drink [drɪŋk] drank [dræŋk] drunk [drʌnk]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("жить; поселить")) && (!scanner().equals("dwell dwelt dwelt"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"dwell [dwel] dwelt [dwelt] (dwelled) dwelt [dwelt] (dwelled)\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("есть")) && (!scanner().equals("eat ate eaten"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"eat [i:t] ate [eɪt], [et] eaten [i:tn]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("падать")) && (!scanner().equals("fall fell fallen"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"fall [fɒl] fell [fel] fallen [fɔ:lən]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("кормить")) && (!scanner().equals("feed fed fed"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"feed [fi:d]  fed [fed] fed [fed]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("чувствовать; думать")) && (!scanner().equals("feel felt felt"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"feel [fi:l] felt [felt] felt [felt]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("бороться")) && (!scanner().equals("fight fought fought"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"fight [faɪt] fought [fɔ:t] fought [fɔ:t]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("находить")) && (!scanner().equals("find found found"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"find [faɪnd] found [faʊnd] found [faʊnd]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("подходить по размеру")) && (!scanner().equals("fit fit fit"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"fit [fɪt] fit [fɪt] fit [fɪt]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("бежать, скрыться")) && (!scanner().equals("flee fled fled"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"flee [fli:] fled [fled] fled [fled]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("бросить; броситься")) && (!scanner().equals("fling flung flung"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"fling [flɪŋ] flung [flʌŋ] flung [flʌŋ]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("летать")) && (!scanner().equals("fly flew flown"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"fly [flaɪ] flew [flu:] flown [fləʊn]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("запрещать")) && (!scanner().equals("forbid forbade forbidden"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"forbid [fə'bɪd] forbade [fə'beɪd] forbidden [fə'bɪdən]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("водить машину")) && (!scanner().equals("drive drove driven"))) {
                System.out.println("Вы допустили ошибку, верно:\n \"drive [draɪv] drove [drəʊv] driven ['drɪvən]\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if ((randStr.equals("ударять не Beat") && (!scanner().equals("hit hit hit")))) {
                System.out.println("Вы допустили ошибку, верно:\n \"hit hit hit\"");
                scanner();
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "класть", "put put put")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "прогнозировать", "forecast forecast forecast")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "забывать", "forget forgot forgotten")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "прощать", "forgive forgave forgiven")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "заморозить; замёрзнуть", "freeze froze frozen")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "получать", "get got got")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "давать", "give gave given")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "идти, ехать", "go went gone")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "расти; выращивать", "grow grew grown")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "висеть; вешать", "hang hung hung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "иметь", "have had had")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "слышать", "hear heard heard")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "прятать; прятаться", "hide hid hidden")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "держать; проводить (мероприятие); поддерживать (беседу)", "hold held held")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "причинять боль", "hurt hurt hurt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "хранить", "keep kept kept")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "вязать", "knit knit knit")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "знать", "know knew known")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "класть; возглавить", "lay laid laid")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "вести", "lead led led")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "наклоняться; прислоняться", "lean leaned leaned")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "вскочить, прыгнуть", "leap leapt leapt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "учить, изучать", "learn learnt learnt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "оставлять", "leave left left")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "давать взаймы", "lend lent lent")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "пускать; позволять", "let let let")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "лежать", "lie lay lain")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "освещать", "light lit lit")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "терять", "lose lost lost")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "делать, создавать", "make made made")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "значить; предназначать; иметь ввиду", "mean meant meant")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "встречать", "meet met met")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "ошибаться", "mistake mistook mistaken")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "косить, стричь", "mow mowed mowed")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
                System.out.println("mow [məʊ] косить, стричь mowed [məʊd] mown [məʊn] mowed");
            } else if (checkVerbs(randStr, "платить", "pay paid paid")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "доказывать", "prove proved proved")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "бросать (работу, университет и т д) бросать что-либо делать (курить и т. д.)",
                    "quit quit quit")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "ездить", "ride rode ridden")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "подняться, вырасти", "rise rose risen")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "пилить", "saw sawed sawed")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "бежать; управлять", "run ran run")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "говорить кратко", "say said said")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "видеть", "see saw seen")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "искать", "seek sought sought")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "продавать; продаваться", "sell sold sold")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "посылать", "send sent sent")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "шить", "sew sewed sewed")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
                System.out.println("sew [səʊ] шить sewed [səʊd] sewn [səʊn],/ sewed");
            } else if (checkVerbs(randStr, "встряхивать", "shake shook shaken")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "сиять, светить", "shine shone shone")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "стрелять; снимать (фильм)", "shoot shot shot")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "показывать", "show showed shown")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "уменьшать", "shrink shrank shrunk")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "закрывать", "shut shut shut")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "петь", "sing sang sung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "тонуть; топить", "sink sank sunk")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "сидеть; садиться", "sit sat sat")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "спать", "sleep slept slept")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "скользить", "slide slid slid")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "закинуть", "sling slung slung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "пахнуть; нюхать", "smell smelt smelt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "сеять", "sow sowed sowed")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "говорить долго", "speak spoke spoken")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "быстро проноситься", "speed sped sped")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "писать или произносить по буквам; влечь за собой", "spell spelt spelt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "проводить (время); тратить", "spend spent spent")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "пролить", "spill spilt spilt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "портить", "spoil spoilt spoilt")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "распространять", "spread spread spread")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "вскочить; появиться", "spring sprang sprung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "стоять; ставить", "stand stood stood")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "красть", "steal stole stolen")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "жалить", "sting stung stung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "колоть; прикалывать, прикреплять; застревать", "stick stuck stuck")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "ударить; врезаться", "strike struck struck")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "стремиться", "strive strove striven")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "клясться; ругаться", "swear swore sworn")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "подметать", "sweep swept swept")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "разбухать", "swell swelled swollen")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "плавать", "swim swam swum")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "качать", "swing swung swung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "брать", "take took taken")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "учить, обучать", "teach taught taught")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "рвать", "tear tore torn")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "говорить, рассказывать", "tell told told")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "думать", "think thought thought")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "бросать t", "throw threw thrown")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "вонзить; толкнуть", "thrust thrust thrust")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "ступать, наступать", "tread trod trodden")) { // начал от сюда
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "будить, просыпаться", "wake woke woken")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "носить (одежду)", "wear wore worn")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "плакать", "weep wept wept")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "мочить", "wet wet wet")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "извиваться", "wind wound wound")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "отжать; свернуть", "wring wrung wrung")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "писать", "write wrote written")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "переменные, параметры;", "variables")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "предыдущий, прежний, прошлый, ранний(early former last);", "previous")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "раздел подраздел;", "section")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "поле(box), область сфера;", "field")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "введенный, внесенный, entered brought, внедренный entered brought embedded;",
                    "introduced")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "правила regulation, условия;", "terms")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "относится;", "refer")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "распространенный;", "common")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "определяет;", "defines")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "типы - k;", "kinds")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "по умолчанию;", "default")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "режим режим работы regime operating ___, способ метод method вид форма type form;",
                    "mode")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "расширять расширить расширяться,преодлевать продлить продлять prolong;",
                    "extend")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "реализовать;", "implement")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "обеспечивать, предусматривать, предоставлять;", "provide")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "доступный, имеющийся;", "available")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "экземпляр,пример, инстанция, образец, (ссылаться, приводить в качестве примера, служить примером);",
                    "instance")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "заказ, порядок, орден (заказывать, приказывать, упорядочивать);",
                    "order")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "повторять, перебирать;", "iterate")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "до тех пор пока, до того как;", "until")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "который, какой;", "which")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "диапазон, ряд, круг (выстраивать в ряд, простираться, тянуться);", "range")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            }  else if (checkVerbs(randStr, "несколько (некоторые, каждый, отдельный);", "several")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "допустимый;", "allowed")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "допустимый;", "allowed")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "потерпеть неудачу;", "fail")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "обязанность, ответственность;", "responsibility")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "способный, в состоянии, умеющий;", "able")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            } else if (checkVerbs(randStr, "cравнивать, сравниться, сопоставлять;", "compare")) {
                attempts++;
                addMistake(mistakeVerbs, randStr);
            }
        }
        if (attempts == 0) {
            System.out.println("\n\tПОЗДРАВЛЯЕМ! НИ ОДНОЙ ОШИБКИ" + "\n\tВЫ ЗАКОНЧИЛИ!");
        } else {
            System.out.println("\n\tколичество ошибок " + attempts + "\n\tВЫ ОШИБЛИСЬ В СЛЕДУЮЩИХ СЛОВАХ:");
            mistakeVerbs = copyFirstFieldsOfArrayNotNull(mistakeVerbs);
            System.out.println(Arrays.toString(mistakeVerbs) + "\n\t СЛОВ НУЖНО ПОВТОРИТЬ! -> " + attempts);
            return mistakeVerbs;
        }
        return words;
    }

    public static String scanner() {
        Scanner verbs = new Scanner(System.in);
        return verbs.nextLine();
    }

    public static String getRandom(String[] array) {
        int rnd = new Random().nextInt(array.length);
        return array[rnd];
    }

    public static String[] removeElement(String[] arr, String item) {
        return Arrays.stream(arr)
                .filter(s -> !s.equals(item))
                .toArray(value -> new String[value]);
    }

    public static boolean checkVerbs(String randStr, String verbRu, String verbEn) {
        boolean rsl = randStr.equals(verbRu) && (!scanner().equals(verbEn));
        if (rsl) {
            System.out.println("Вы допустили ошибку, верно: " + "\"" + verbEn + "\"");
            while (!scanner().equals(verbEn)) {
                System.out.println("Вы сново ошиблись верно: " + "\"" + verbEn + "\"");
            }
        }
        return rsl;
    }

    public static void addMistake(String[] arr, String verbRu) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == null) {
                arr[i] = verbRu;
                break;
            }
        }
    }

    public static String[] copyFirstFieldsOfArrayNotNull(String[] source) {
        String[] temp = new String[source.length];
        int count = 0;
        for (int i = 0; i < source.length; i++) {
            if (source[i] != null) {
                temp[count++] = source[i];
            }
        }
        source = Arrays.copyOf(temp, count++);
        return source;
    }
}
