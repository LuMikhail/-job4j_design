package ru.job4j.inheritance;

public class Base {

    public Base() {
        System.out.println("Default Base constructor.");
    }
}
