package ru.job4j.trackercopi.shablonstrateg;

public class King extends Character {

    public King() {
        weaponBehavior = new SwordBehavior();
    }

    @Override
    public void display() {
        System.out.println("Im strike bake");
    }
}
