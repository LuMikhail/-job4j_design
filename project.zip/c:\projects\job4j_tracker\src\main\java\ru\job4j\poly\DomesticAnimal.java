package ru.job4j.poly;

public class DomesticAnimal extends Animal {
    public void liveOnFarm() {
        System.out.println(nameClass + " живет на ферме приносит пользу");
    }
}
