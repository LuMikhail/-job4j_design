package ru.job4j.inheritance;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class UsagePackageDate {
    public static void main(String[] args) {
        LocalDate currentDate = LocalDate.now();
        System.out.println("Текущая дата: " + currentDate);
        LocalTime curentTime = LocalTime.now();
        System.out.println("Текущие время: " + curentTime);
        LocalDateTime currentDateTime = LocalDateTime.now();
        System.out.println(currentDateTime);
    }
}
