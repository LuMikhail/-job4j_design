package ru.job4j.trackercopi.shablonstrateg;

public class Read {
}
