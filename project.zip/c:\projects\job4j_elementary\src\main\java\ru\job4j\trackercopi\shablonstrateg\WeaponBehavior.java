package ru.job4j.trackercopi.shablonstrateg;

public interface WeaponBehavior {
    void useWeapon();
}
