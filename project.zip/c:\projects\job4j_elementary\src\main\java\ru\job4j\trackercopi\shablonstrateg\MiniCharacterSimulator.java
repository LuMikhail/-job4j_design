package ru.job4j.trackercopi.shablonstrateg;

public class MiniCharacterSimulator {
    public static void main(String[] args) {
        Character fightWeapon = new Troll();
        fightWeapon.display();
        fightWeapon.performFight();
        fightWeapon.setWeaponBehavior(new KnifeBehavior());
        fightWeapon.performFight();
    }
}
