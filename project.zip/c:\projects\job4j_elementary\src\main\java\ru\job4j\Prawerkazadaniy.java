package ru.job4j;

public class Prawerkazadaniy {
    public static void main(String[] args) {
        int size = 10;
        System.out.println(size);
        size = 100;
        System.out.println(size);
        size = size - 5;
        System.out.println(size);

    }
}
