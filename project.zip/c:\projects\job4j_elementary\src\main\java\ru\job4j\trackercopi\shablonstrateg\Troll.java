package ru.job4j.trackercopi.shablonstrateg;

public class Troll extends Character {

    public Troll() {
        weaponBehavior = new AxeBehavior();
    }

    @Override
    public void display() {
        System.out.println("It s mi Row");
    }

}
