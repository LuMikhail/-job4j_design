package ru.job4j.trackercopi.io;

public class Animal implements Sleepable {
    public void walk() {
        System.out.println("Animal walking");
    }

    @Override
    public void sleep() {
        System.out.println("Animal sleeping");
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }
}
