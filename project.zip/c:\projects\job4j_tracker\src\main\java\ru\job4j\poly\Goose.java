package ru.job4j.poly;

public class Goose extends DomesticAnimal {
    public void bringFeather() {
        System.out.println(nameClass + " приносит перо для подушек.");
    }
}
