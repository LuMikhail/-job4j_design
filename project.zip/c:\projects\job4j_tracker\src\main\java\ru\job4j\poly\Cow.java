package ru.job4j.poly;

public class Cow extends DomesticAnimal {
    public void giveMilk() {
        System.out.println(nameClass + " дает человеку молоко");
    }
}
