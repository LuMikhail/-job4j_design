package ru.job4j.scaner;

import java.util.Scanner;

public class PracticeScaner {
    public static void main(String[] args) {

    Scanner input = new Scanner(System.in);
    int x = input.nextInt();
    int y = input.nextInt();
    int sum = x + y;
    System.out.println(sum);
    Scanner in = new Scanner(System.in);
    double a = in.nextDouble();
    double b = in.nextDouble();
    double summ = a + b;
        System.out.println(summ);
    }
}
