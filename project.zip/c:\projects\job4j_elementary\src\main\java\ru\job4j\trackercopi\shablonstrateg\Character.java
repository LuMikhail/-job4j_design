package ru.job4j.trackercopi.shablonstrateg;

public abstract class Character {

    WeaponBehavior weaponBehavior;

    abstract public void display();

    public void setWeaponBehavior(WeaponBehavior weaponBehavior) {
        this.weaponBehavior = weaponBehavior;
    }

    public void performFight() {
        weaponBehavior.useWeapon();
    }
}
