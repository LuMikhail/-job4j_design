package ru.job4j.trackercopi.shablon.fabric;

public class RomeWatch implements Watch {

    @Override
    public void showTime() {
        System.out.println("Римские часы которые показывают" + "VI X");
    }
}
