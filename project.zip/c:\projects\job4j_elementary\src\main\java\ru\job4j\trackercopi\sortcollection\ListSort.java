package ru.job4j.trackercopi.sortcollection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ListSort {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 3, 4, 1, 2);
        System.out.println(list);
        Collections.sort(list);
        System.out.println(list);
        String petr = "Petr";
        String ivan = "Ivan";
        int rsl = petr.compareTo(ivan);
        System.out.println(rsl);
        String dmitriy = "Dmitriy";
        List<String> strings = Arrays.asList(petr, dmitriy, ivan);
        System.out.println(strings);
        Collections.sort(strings);
        System.out.println("Отсортировать строки по возростанию " + strings);
        Collections.sort(strings, Collections.reverseOrder());
        System.out.println("Отсортировать строки по убыванию " + strings);
    }
}
