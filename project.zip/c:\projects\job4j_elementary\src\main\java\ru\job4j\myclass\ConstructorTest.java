package ru.job4j.myclass;

import java.util.*;

public class ConstructorTest {
    public static void main(String[] args) {
        // заполняем масси staff тремя объектами типа Employee
        var staff = new Employee[3];
        staff[0] = new Employee("Harry", 40000);
        staff[1] = new Employee(60000);
        staff[2] = new Employee();
        // вывести данные обо всех объектах типа Employee
        for (Employee e : staff) {
            System.out.println("name=" + e.getName() + ", id=" + e.getId() + ", salary=" + e.getSalary());
        }
    }
}

class Employee {

    private static int nextid;
    private int id;
    private String name = ""; // инициализация поля экземпляра
    private double salary;

    // статический блок инициализации
    static {
        var generator = new Random();
        // задать произвольное число 0-999 в поле nextid
        nextid = generator.nextInt(10000);
    }

    // блок инициализации объекта
    {
        id = nextid;
        nextid++;
    }

    // три перезагружаемых конструкторра
    public Employee(String n, double s) {
        name = n;
        salary = s;
    }

    public Employee(double s) {
        // вызвать конструктор Employee(String, double)
        this("Employee #" + nextid, s);
    }

    // конструктор без аргументов
    public Employee() {
        //  поле name инициализируется пустой строкой "" -
        // поле salary не устанавливается явно, см выше; а инициализируется нулем
        // поле id инициализируестя в блоке инициализации
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public int getId() {
        return id;
    }
}