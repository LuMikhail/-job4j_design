package ru.job4j.trackercopi.lambda;

import java.util.function.Function;

public class FieldSeeLambda {
    public static int sx = 40;
    public static final int MY_CONST = 50;
    private int cy = 125;

    public void print() {
        int x = 10;
        final int y = 20;
        int cyTemp = this.cy;
        int cxTemp = FieldSeeLambda.sx;
        // x = 1;
        Function<Integer, Integer> f = n -> {
            System.out.print(cyTemp + " "); // 125
            System.out.print(this.cy + " "); // 10
            System.out.print(cxTemp + " "); //40
            System.out.print(FieldSeeLambda.sx); //50
            //  n = n + z; нельзя не определена z
            // x = 1; так не льзя x константа
            FieldSeeLambda.sx += 10; // изминение статической переменной
            this.cy += 5; // изменение поля
            FieldSeeLambda.test();
            this.echo(); // доступ к методу
            return n + x + y + FieldSeeLambda.sx + MY_CONST + this.cy;
        };
        System.out.println(f.apply(0)); // вывод лямда -  выражения 0+10+20+(40+10)+50+(125+5)=260
        System.out.println();
        int z = 2; // к этой переменной нет доступа
        System.out.println(f.apply(0)); // вывод лямда -  выражения 260+15=275
        System.out.println(f.apply(0)); // вывод лямда -  выражения 275+15=290
        System.out.println(f.apply(0)); // вывод лямда -  выражения 290+15=305
        this.cy = 10; // изменения значения после создания лямбды
        //System.out.println(f.apply(0)); // вывод лямда -  выражения
        FieldSeeLambda.sx = 50;
        System.out.print(" " + f.apply(0)); // вывод лямда -  выражения // //0+10+20+(50+10)+50+(10+5)=155
    }

    public void echo() {
        System.out.print("echo()");
    }

    public static void test() {
        System.out.print("test()");
    }

    public static void main(String[] args) {
        FieldSeeLambda obj = new FieldSeeLambda();
        obj.print();
    }
}
