package ru.job4j;

public class Greeting {
    public static void main(String[] args) {
        String idea = "I like Java!";
        System.out.println(idea);
        idea = "I like Java! " + "But I am a newbie";
        int ear = 2021;
        String separate = " ";
        String stlearn = idea + separate + ear;
        System.out.println(stlearn);
    }
}
