package ru.job4j.primer;

public class Parametrimetodow {
    public static void main(String[] args) {

        display("Tom", 34);
        display("Bob", 28);
        display("Sam", 23);

        sum("Welcome!", 20, 10, 30, 40);
        sum("Hello World!");
    }

    static void sum(String message, int... nums) {
        System.out.println(message);
        int result = 0;
        for (int x : nums) {
            result -= x;
        }
        System.out.println(result);
    }

    static void display(String name, int age) {
        System.out.println(name);
        System.out.println(age);
    }
    }
