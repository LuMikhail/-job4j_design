package ru.job4j.trackercopi.lamda;

import java.text.Annotation;
import java.util.*;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

public class AttachmentSort {
    public static void main(String[] args) {
        List<Attachment> attachments = Arrays.asList(
                new Attachment("image 1", 100),
                new Attachment("image 2", 34),
                new Attachment("image 3", 13)

        );

        Comparator<Attachment> comparator = Comparator.comparingInt(Attachment::getSize);
        attachments.sort(comparator);
        for (Attachment a : attachments) {
            System.out.println(a);
        }

        ArrayList<Integer> list = new ArrayList<>() {
            @Override
            public boolean add(Integer o) {
                System.out.println("Add a new element to list: " + o);
                return super.add(o);
            }
        };
        list.add(100500);
        System.out.println(attachments);
    }
}
