package ru.job4j.poly;

public interface Transport {

    void drive();

    void numberOfPassengers(int passengers);

   double prise(int fill);
}
