package ru.job4j.trackercopi.algorithm;

import java.util.Arrays;

public class SortSpark {
    public static void main(String[] args) {
        int[] arr = {29, 5, 1, 16, 3, 14, 48, 9};
        System.out.println(Arrays.toString(arr));
        System.out.println();
        sort(arr);
        System.out.println(Arrays.toString(arr));
    }

    public static void sort(int[] arr) {
        int temp;
        for (int k = arr.length - 1; k >= 1; k--) {
            for (int i = 0; i < k; i++) {
                if (arr[i] > arr[k]) {
                    temp = arr[i];
                   arr[i] = arr[k];
                   arr[k] = temp;
                }
            }
        }
    }
}
