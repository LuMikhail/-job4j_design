package ru.job4j.trackercopi.shablon.fabric;

public class FactoryMethodAPP {
    public static void main(String[] args) {
        Watch watch = new RomeWatch(); // просто создали интерфейс
        watch.showTime();
        WatchMaker maker = getMakerName("Rome"); // фабрика часов
        Watch watch1 = maker.createWatch();
        watch1.showTime();
    }

    public static WatchMaker getMakerName(String name) {
        if (name.equals("Digital")) {
            return new DigitalWatchMaker();
        } else if (name.equals("Rome")) {
            return new RomeWatchMaker();
        }
        throw new RuntimeException("Не поддерживаемая линия производителя часов: " + name);
    }
}
