package ru.job4j.trackercopi.shablon.fabric;

public interface Watch {
    void showTime();
}
