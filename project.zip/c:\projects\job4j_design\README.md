# job4j_design

## О проекте: В этом проекте изучение языка Java на курсе job4j.

<h3> Блок 1. Структуры данных и алгоритмы:</h3>
<ol>
<li>Iterator</li>
<li>Generic</li>
<li>List</li>
<li>Set</li>
<li>Map</li>
<li>Tree</li>
<li>Экзамен</li>
</ol>

<h3> Блок 2. Ввод-вывод:</h3>
<ol>
<li>Ввод-вывод</li>
<li>Socket</li>
<li>Логгирование</li>
<li>Сериализация</li>
<li>Экзамен</li>
</ol>

