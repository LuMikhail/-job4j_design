package ru.job4j.trackercopi.io;

import java.util.Arrays;

public class EmployeeSortTest {
    public static void main(String[] args) {
        var staff = new Employee[3];
        staff[0] = new Employee("Hsker", 70000);
        staff[1] = new Employee("Mark", 57000);
        staff[2] = new Employee("Tony", 38000);
        Arrays.sort(staff);
        for (int i = 0; i < staff.length; i++) {
            System.out.println(i + ". " + staff[i].getName() + " - " + staff[i].getSalary());
        }
        System.out.println("Повышение зарплаты на ");
        for (int i = 0; i < staff.length; i++) {
            staff[i].raiseSalary(5);
            System.out.println(i + ". " + staff[i].getName() + " - " + staff[i].getSalary());
        }
    }
}
