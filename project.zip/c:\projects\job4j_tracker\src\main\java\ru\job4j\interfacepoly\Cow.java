package ru.job4j.interfacepoly;

public class Cow implements Animal {
    @Override
    public void sound() {
        System.out.println(getClass().getSimpleName() + " дает человеку молоко");
    }
}
