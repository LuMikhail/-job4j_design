package ru.job4j.trackercopi.oop;

public class Calculator {

    private static  int x = 5;

    public static int sum(int y) {
        return  x + y;
    }

    public static int minus(int d) {
        return  d - x;
    }

    public int multiply(int a) {
        return x * a;
    }

    public int sumAllOperation(int d, int y, int a) {
        return minus(d) + sum(y) + multiply(a);

    }

    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        int resultMultiply = calculator.multiply(5);
        int resultSum = Calculator.sum(10);
        int resultMinus = Calculator.minus(10);
        int sumAll = calculator.sumAllOperation(10, 10, 5);
        System.out.println("Результат сумирования: " + resultSum);
        System.out.println("Результат умножения: " + resultMultiply);
        System.out.println("Результат вычитатния: " + resultMinus);
        System.out.println("Результат сложения операторов: " + sumAll);
    }
}
