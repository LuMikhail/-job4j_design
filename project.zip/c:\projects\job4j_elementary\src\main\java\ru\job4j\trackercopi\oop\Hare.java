package ru.job4j.trackercopi.oop;

public class Hare {

    public void eat(Ball ball) {
     ball.truRun(false);
        }
    }
