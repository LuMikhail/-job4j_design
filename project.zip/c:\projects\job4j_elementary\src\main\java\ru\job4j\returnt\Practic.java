package ru.job4j.returnt;

public class Practic {
    public static void main(String[] args) {
        int x = sum(5, 7);
        System.out.println(x);
        int y = sum2();
        System.out.println(y);
        Practic name2 = new Practic(); // нужно создать обект  так как метод name не статический
        name2.name("Mikhail");
        int max = name2.max(5, 35); // метод не static
        surname(); // метод static  ез параметров
        System.out.println("Максимальное число: "  + max);
        System.out.println("Максимальное число: " + name2.max(15, 17));
        System.out.println(fullName("Mikhail", "Luzkovskiy"));
    }

    public static int sum(int a, int b) {
        return a + b;
    }

    public static int sum2() {
       int a =  10;
       int b = 11;
       int  s = a + b;
        return s;
    }

    public void name(String s) {
        System.out.println("You name is " + s);
    }

    public static void surname() {
        System.out.println("Belik");
    }

    public int max(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return  b;
        }
    }

    public static String fullName(String name, String surname) {
        String fullName = "";
        fullName = name + " " + surname;
        return fullName;
    }
}
