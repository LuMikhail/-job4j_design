package ru.job4j.trackercopi.shablon;

import ru.job4j.trackercopi.learningwords.Irregularverbs;

import java.util.Arrays;

public class Mistake {
    public static void main(String[] args) {
        String[] exercise = new String[10];
        System.out.println(Arrays.toString(exercise));
        Irregularverbs.addMistake(exercise, "son");
        Irregularverbs.addMistake(exercise, "jon");
        Irregularverbs.addMistake(exercise, "koi");
        Irregularverbs.addMistake(exercise, "mama");
        System.out.println(Arrays.toString(exercise));
        exercise = copyFirstFieldsOfArrayNotNull(exercise);
        System.out.println(Arrays.toString(exercise));
    }

    private static String[] copyFirstFieldsOfArrayNotNull(String[] source) {
        String[] temp = new String[source.length];
        int count = 0;
        for (int i = 0; i < source.length; i++) {
            if (source[i] != null && !source[i].equals("son")) {
                temp[count++] = source[i];
            }
        }
        source = Arrays.copyOf(temp, count++);
        return source;
    }
}
