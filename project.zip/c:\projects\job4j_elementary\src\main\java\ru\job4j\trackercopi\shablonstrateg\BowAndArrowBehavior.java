package ru.job4j.trackercopi.shablonstrateg;

public class BowAndArrowBehavior implements WeaponBehavior {
    @Override
    public void useWeapon() {
        System.out.println("I shoot Arrow");
    }
}
