package ru.job4j.trackercopi.io;

public interface Sleepable extends Comparable, Cloneable {
    void sleep();
}
