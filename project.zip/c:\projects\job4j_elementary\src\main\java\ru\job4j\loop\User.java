package ru.job4j.loop;

public class User {
    public static void convert() {
        String name = "Petr Arsentev";
    }
}
