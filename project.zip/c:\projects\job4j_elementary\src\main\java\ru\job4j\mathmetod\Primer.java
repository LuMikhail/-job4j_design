package ru.job4j.mathmetod;

public class Primer {
    public static void main(String[] args) {
        System.out.println(Math.PI);
        System.out.println(Math.E);
        System.out.println();
        System.out.println(Math.sin(30)); // синус
        System.out.println(Math.exp(1));
        System.out.println(Math.log10(100)); // 2
        System.out.println(Math.log(Math.E)); // 1
        System.out.println(Math.pow(2, 3)); // 2 ^3
        System.out.println(((Math.sqrt(121)))); // корень 11
        System.out.println();
        // методы округления
        System.out.println(Math.ceil(3.1));
        System.out.println(Math.ceil(3.0));
        System.out.println(Math.floor(3.9));
        System.out.println(Math.floor(3.0));
        System.out.println(Math.rint(3.5));
        System.out.println(Math.rint(3.3));
        System.out.println(Math.rint(2.5));
        System.out.println(Math.round(3.5)); // целые чилса по правилам округления
        System.out.println(Math.round(2.5)); // целые числа по правилам округления
        System.out.println();
        System.out.println(Math.min(125, 136));
        System.out.println(Math.max(14, 158));
        System.out.println(Math.abs(-8));
        System.out.println(Math.abs(8));
        System.out.println((int) (Math.random() * 100));
    }
}
