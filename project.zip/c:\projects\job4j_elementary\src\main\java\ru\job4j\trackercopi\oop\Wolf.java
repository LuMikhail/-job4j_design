package ru.job4j.trackercopi.oop;

public class Wolf {

    public void eat(Girl girl) {

    }

    public void eat(Ball ball) {
        ball.truRun(false);
    }
}
