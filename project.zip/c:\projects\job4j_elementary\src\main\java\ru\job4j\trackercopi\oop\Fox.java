package ru.job4j.trackercopi.oop;

public class Fox {

    public void eat(Ball ball) {
        ball.truRun(true);
    }
}
