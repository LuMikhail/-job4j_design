package ru.job4j.interfacepoly;

public interface Animal {
    void sound();
}
