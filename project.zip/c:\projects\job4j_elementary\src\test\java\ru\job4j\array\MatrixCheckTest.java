package ru.job4j.array;

import org.junit.Assert;
import org.junit.Test;

    public class MatrixCheckTest {

        @Test
        public void whenHasMonoHorizontal() {
            char[][] input = {
                    {' ', ' ', ' '},
                    {'X', 'X', 'X'},
                    {' ', ' ', ' '},
            };
            int row = 1;
            boolean result = MatrixCheck.monoHorizontal(input, row);
            Assert.assertTrue(result);
        }

        @Test
        public void whenHasMonoHorizontalFalse() {
            char[][] input = {
                    {' ', ' ', ' '},
                    {'X', 'X', ' '},
                    {' ', ' ', ' '},
            };
            int row = 1;
            boolean result = MatrixCheck.monoHorizontal(input, row);
            Assert.assertFalse(result);
        }

        @Test
        public void whenHasMonoVertical() {
            char[][] input = {
                    {' ', ' ', 'X'},
                    {' ', ' ', 'X'},
                    {' ', ' ', 'X'},
            };
            int column = 2;
            boolean result = MatrixCheck.monoVertical(input, column);
            Assert.assertTrue(result);
        }

        @Test
        public void whenHasMonoVerticalOne() {
            char[][] input = {
                    {' ', 'X', ' '},
                    {' ', 'X', ' '},
                    {' ', 'X', ' '},
            };
            int column = 1;
            boolean result = MatrixCheck.monoVertical(input, column);
            Assert.assertTrue(result);
        }

        @Test
        public void whenHasMonoVerticalFalse() {
            char[][] input = {
                    {' ', 'X', ' '},
                    {' ', ' ', ' '},
                    {' ', 'X', ' '},
            };
            int column = 1;
            boolean result = MatrixCheck.monoVertical(input, column);
            Assert.assertFalse(result);
        }

        @Test
        public void whenDiagonalFullX() {
            char[][] input = {
                    {'X', ' ', ' '},
                    {' ', 'X', ' '},
                    {' ', ' ', 'X'},
            };
            char[] result = MatrixCheck.extractDiagonal(input);
            char[] expected = {'X', 'X', 'X'};
            Assert.assertArrayEquals(expected, result);
        }

        @Test
        public void whenDiagonalFullOne() {
            char[][] input = {
                    {'1', ' ', ' '},
                    {' ', '1', ' '},
                    {' ', ' ', '1'},
            };
            char[] result = MatrixCheck.extractDiagonal(input);
            char[] expected = {'1', '1', '1'};
            Assert.assertArrayEquals(expected, result);
        }

        @Test
        public void whenDiagonalMix() {
            char[][] input = {
                    {'X', ' ', ' '},
                    {' ', 'Y', ' '},
                    {' ', ' ', 'Z'},
            };
            char[] result = MatrixCheck.extractDiagonal(input);
            char[] expected = {'X', 'Y', 'Z'};
            Assert.assertArrayEquals(expected, result);
        }

        @Test
        public void whenDataMonoByTrueThenTrue() {
            char[][] input = {
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
            };
            boolean result = MatrixCheck.isWin(input);
            Assert.assertTrue(result);
        }

        @Test
        public void whenDataNotMonoByTrueThenFalse() {
            char[][] input = {
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', 'X', ' ', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
            };
            boolean result = MatrixCheck.isWin(input);
            Assert.assertFalse(result);
        }

        @Test
        public void whenDataHMonoByTrueThenTrue() {
            char[][] input = {
                    {' ', ' ', ' ', ' ', ' '},
                    {' ', ' ', ' ', ' ', ' '},
                    {'X', 'X', 'X', 'X', 'X'},
                    {' ', ' ', 'X', ' ', ' '},
                    {' ', ' ', 'X', ' ', ' '},
            };
            boolean result = MatrixCheck.isWin(input);
            Assert.assertTrue(result);
        }
    }
