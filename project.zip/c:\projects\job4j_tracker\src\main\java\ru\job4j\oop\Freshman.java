package ru.job4j.oop;

public class Freshman extends Student {

    public void freshmanNikolai() {
        System.out.println("I am a first-year student Nikolai");
    }
}
