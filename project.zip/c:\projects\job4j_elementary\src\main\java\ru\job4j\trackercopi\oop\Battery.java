package ru.job4j.trackercopi.oop;

public class Battery {

    private int load;

    public Battery(int load) {
        this.load = load;
    }

    public void exchange(Battery another) {
        another.load = this.load + another.load;
    }

    public int getLoad() {

        return load;
    }

    public static void main(String[] args) {
        Battery charger  = new Battery(80);
        Battery another  = new Battery(20);
        charger.exchange(another);
        System.out.println("charger " + charger.load + " another " + another.load);

    }
}
