package ru.job4j.employee;

import java.time.LocalDate;

public class Employeeperson extends Person {
    private double salary;
    private LocalDate heriDay;

    public Employeeperson(String name, double salary, int year, int month, int day) {
        super(name);
        this.salary = salary;
        heriDay = LocalDate.of(year, month, day);
    }

    public double getSalary() {
        return  salary;
    }

    public LocalDate getHeriDay() {
        return  heriDay;
    }

    public String getDescription() {
        return String.format(
                "an employee with a salary of $%.2f", salary);
    }

    public  void  raiseSalary(double byPersent) {
        double raise = salary * byPersent / 100;
        salary += raise;
    }
}
