package ru.job4j.trackercopi.learningwords;

import java.util.Arrays;

public class PostgreSQL {
    public static void main(String[] args) {
        String[] postgreSQL = {"создание таблицы;", "удаление таблицы;", "первичный ключ;",
                "уникальное значение на уровне таблицы Email, Phone;", "значение по умолчанию;",
                "создать ограничение на уровне таблицы \n Age >0  Age<100 Email !='' Phone !=''",
                "в таблице Customers добавить столбец Phone;", "Удалим столбец Address из таблицы Customers;",
                "Добавление ограничения таблицы Customers Age > 0;", "Переименуем столбец Address в City в таблице Customers;",
                "Переименуем таблицу Customers в Users;"};
        System.out.println("Здравствуйте,  это программа поможет вам выучить технические команды PostgreSQL");
        System.out.println("            НАЧНЕМ:");
        long start = System.currentTimeMillis();
        String[] repeatWords = PostgreSQL.learningWords(postgreSQL); // так как метод возвращает String[] мы сначала воспроизводим words
        // а затем записываем новый массив из слов в которых мы ошиблись.
        if (repeatWords.length > 0) { // если есть ошибки
            for (String w : repeatWords) {
                System.out.println(w);
            }
            System.out.println("\n повторим один раз \n");
            String[] againRepeat = PostgreSQL.learningWords(repeatWords); // то записываем в новый масcив
            if (againRepeat.length > 0) {
                System.out.println(Arrays.toString(againRepeat));
                PostgreSQL.learningWords(againRepeat); // опять повторяем слова в которых допустили ошибки
            }
        }

        float finish = (float) (System.currentTimeMillis() - start) / 60000;
        System.out.println("Время выполнение упражнения составляет " + finish + " минут");
    }

    public static String[] learningWords(String[] words) {
        System.out.print("команд в этом блоке: ");
        System.out.print(words.length); // печатаем количество глаголов которое равно конец длинны массива
        System.out.println();
        int rsl = 0;
        int attempts = 0; // счетает количество ошибок
        String[] mistake = new String[50];
        while (rsl < words.length) {
            String randStr = Irregularverbs.getRandom(words); // генерируем случайный глагол через индекс массива с глаголами
            words = Irregularverbs.removeElement(words, randStr); // уменьшаем количество слов на пройденное слово
            System.out.print("Введите команду: ");
            System.out.println(randStr);
            if (Irregularverbs.checkVerbs(randStr, "создание таблицы;", "CREATE TABLE")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr, "удаление таблицы;", "DROP TABLE")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr, "первичный ключ;", "PRIMARY KEY")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "уникальное значение на уровне таблицы Email, Phone;", "UNIQUE (Email, Phone)")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr, "значение по умолчанию;", "DEFAULT")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "создать ограничение на уровне таблицы \n Age >0  Age<100 Email !='' Phone !=''",
                    "CHECK((Age > 0 AND Age < 100) AND (Email !='') AND (Phone !=''))")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "в таблице Customers добавить столбец Phone;",
                    "ALTER TABLE Customers ADD Phone")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "Удалим столбец Address из таблицы Customers;",
                    "ALTER TABLE Customers DROP COLUMN Address")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "Добавление ограничения таблицы Customers Age > 0;",
                    "ALTER TABLE Customers ADD CHECK (Age > 0)")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "Добавление ограничения таблицы Customers Age > 0;",
                    "ALTER TABLE Customers RENAME COLUMN Address TO City")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "Переименуем таблицу Customers в Users;",
                    "ALTER TABLE Customers RENAME TO Users")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            } else if (Irregularverbs.checkVerbs(randStr,
                    "Переименуем столбец Address в City в таблице Customers;",
                    "ALTER TABLE Customers RENAME COLUMN Address TO City")) {
                attempts++;
                Irregularverbs.addMistake(mistake, randStr);
            }
        }
        if (attempts == 0) {
            System.out.println("\n\tПОЗДРАВЛЯЕМ! НИ ОДНОЙ ОШИБКИ" + "\n\tВЫ ЗАКОНЧИЛИ!");
        } else {
            System.out.println("\n\tколичество ошибок " + attempts + "\n\tВЫ ОШИБЛИСЬ В СЛЕДУЮЩИХ КОМАНДАХ:");
            mistake = Irregularverbs.copyFirstFieldsOfArrayNotNull(mistake);
            System.out.println(Arrays.toString(mistake) + "\n\t КОМАНДЫ НУЖНО ПОВТОРИТЬ! -> " + attempts);
            return mistake;
        }
        return words;
    }
}
