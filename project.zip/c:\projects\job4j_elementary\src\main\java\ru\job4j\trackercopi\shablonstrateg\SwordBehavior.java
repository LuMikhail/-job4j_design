package ru.job4j.trackercopi.shablonstrateg;

public class SwordBehavior implements WeaponBehavior {

    @Override
    public void useWeapon() {
        System.out.println("I beat Sword");
    }
}
