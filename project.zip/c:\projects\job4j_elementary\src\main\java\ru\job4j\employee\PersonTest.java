package ru.job4j.employee;

public class PersonTest {
    public static void main(String[] args) {
        Person[] people = new Person[2];
        people[0] = new Employeeperson("Hary Haker", 50000, 1989, 10, 11);
        people[1] = new Student("Mariy Moris", "Computer science");
        for (Person p: people
             ) {
            System.out.println(p.getName() + ", " + p.getDescription());
        }
    }
}
