package ru.job4j.trackercopi.oop;

public class Error {

    boolean active;
    int status;
    String message;

    public Error() {

    }

    public Error(boolean active, int status, String message) {
        this.active = active;
        this.status = status;
        this.message = message;
    }

    public void print() {
        System.out.println("Ошибка: " + active);
        System.out.println("код ошибки: " + status);
        System.out.println("Для исправления ошибки " + message);
    }

    public static void main(String[] args) {
        Error notError = new Error();
        notError.print();
        Error virus = new Error(true, 19, "Запустите антивирус!");
        virus.print();
        Error noPrinting = new Error(true, 5, "Включите принтер.");
        noPrinting.print();
    }
}
