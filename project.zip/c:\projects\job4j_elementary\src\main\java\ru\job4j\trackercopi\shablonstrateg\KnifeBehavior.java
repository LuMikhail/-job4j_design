package ru.job4j.trackercopi.shablonstrateg;

public class KnifeBehavior implements WeaponBehavior {

    @Override
    public void useWeapon() {
        System.out.println("I hit knife");
    }
}
