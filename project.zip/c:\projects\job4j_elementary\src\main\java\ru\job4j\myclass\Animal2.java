package ru.job4j.myclass;

public class Animal2 {
    public static void main(String[] args) {
        Cat albotros = new Cat("Albotres");
        albotros.speake();
    }
}

class Animal {
    private String name;
    private String voice;

    public Animal(String name, String voice) {
        this.name = name;
        this.voice = voice;
    }

    public void speake() {
        System.out.println(this.name + " says " + this.voice);
    }
}

class Cat extends Animal {

    public Cat(String name) {
        super(name, "meowe");
    }
}

