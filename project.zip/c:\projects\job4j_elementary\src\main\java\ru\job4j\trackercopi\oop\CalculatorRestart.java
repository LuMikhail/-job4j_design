package ru.job4j.trackercopi.oop;

public class CalculatorRestart {

    public  double add(double first, double second) {

        return first + second;
    }

    public  double add(double first, double second, double third) {
        return add(third, add(second, first));
        }

    public static void main(String[] args) {
        CalculatorRestart result = new CalculatorRestart();
        System.out.println(result.add(1, 2, 7.748));
    }
}
